from flask import Blueprint,render_template,request,flash,jsonify,redirect,url_for
from werkzeug.security import generate_password_hash
from flask_login import current_user,login_required
from plotly.express import pie,bar
from plotly.figure_factory import create_annotated_heatmap
from plotly.utils import PlotlyJSONEncoder
from json import dumps,loads
from ..model.user import User
from ..model.students import db,Student
from ..utils.forms import StudentForm,EditAccountForm,AddUserForm,StudentDataFile,StudentGradeForm,StudentGradeSemesterForm
from ..utils import is_admin,to_tables,check_files
from .process import Process
import pandas as pd
import traceback
import sys

admin = Blueprint("admin",__name__)

@admin.route("/",methods=["GET","POST"])
@login_required
@is_admin
def index():
    forms: EditAccountForm = EditAccountForm()

    if request.method == "POST" and forms.validate_on_submit():
        _user = User.query.filter_by(id=current_user.id).first()
        _user.password = generate_password_hash(forms.password1.data)
        flash("Password berhasil diperbaharui",category="success")
        return redirect(url_for("admin.index"))

    forms.email.data = current_user.email
    return render_template("admin/index.html",forms=forms)

@admin.route("/student")
def student():
    students = Student.query.all()

    id_url = "admin.edit_student"

    students = to_tables(students,drop_column=["_sa_instance_state"],reorder_column=["id","name","major","score","extra_activity","academic_achievement","nonacademic_achievement"],rename_column={"name": "Nama murid","major": "Jurusan","score": "Nilai raport","extra_activity": "Keaktifan ekskul","academic_achievement": "Prestasi akademik","nonacademic_achievement": "Prestasi non-academic"},id_url=id_url,url_id="id")

    return render_template("admin/tables.html",tables=students,add_url="admin.add_student",add_button_text="Tambah murid baru",title="Murid")

@admin.route("/student/add",methods=["GET","POST"])
@is_admin
@login_required
def add_student():
    forms: StudentDataFile = StudentDataFile()

    if request.method == "POST" and forms.validate_on_submit():
        files = request.files[forms.student_data.name]

        if files.content_type != "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
            flash("File harus berbentuk file excel",category="danger")
            return redirect(url_for("admin.add_student"))

        excel = pd.read_excel(files)
        _student = pd.DataFrame()
        try:
            try:
                _student = pd.DataFrame({"name": excel["nama"],"major": excel["jurusan"],"score": excel["nilai"],"extra_activity": excel["keaktifan_ekskul"],"academic_achievement": excel["prestasi_akademik"],"nonacademic_achievement": excel["prestasi_nonakademik"]})
            except KeyError as e:
                flash(f"kolom {e} tidak ada pada file excel",category="")
                return redirect(url_for("admin.add_student"))
        
            student = _student.to_dict(orient="records")
            print(student)
            db.session.bulk_insert_mappings(Student, student)
            db.session.commit()        
        except Exception as e:
            flash(f"error: {e}")
        else:
            return redirect(url_for("admin.student"))

    forms.student_data.label = "Tambah data murid"
    return render_template("admin/add.html",forms=forms,title="Tambah murid",btn_title="murid")

@admin.route("/student/edit/<int:id>",methods=["GET","POST"])
@is_admin
@login_required
def edit_student(id):
    forms: StudentForm = StudentForm()
    _student: Student = Student.query.filter_by(id=id).first()

    if request.method == "POST" and forms.validate_on_submit():
        _student.name = forms.name.data
        _student.major = forms.major.data
        _student.score = forms.score.data
        _student.extra_activity = forms.extra_activity.data
        _student.academic_achievement = forms.academic_achievement.data
        _student.nonacademic_achievement = forms.nonacademic_achievement.data           
        _student.accept_status = forms.accept_status.data

        db.session.commit()
        flash(f"Data murid {{_student.name}} berhasil diupdate",category="success")
        return redirect(url_for("admin.student"))                                            
    # _class = Student.query.all()
    # _class = pd.DataFrame([query.__dict__ for query in _class])

    forms.name.data = _student.name
    forms.major.data = _student.major    
    forms.score.data = _student.score
    forms.extra_activity.data = _student.extra_activity
    forms.academic_achievement.data = _student.academic_achievement
    forms.nonacademic_achievement.data = _student.nonacademic_achievement
    forms.accept_status.data = _student.accept_status

    return render_template("admin/add.html",forms=forms,title="Edit murid",edit=True,btn_title="murid",data=_student,id=id)

@admin.route("/student/classification")
def process():
    students = Student.query.all()    
    query = pd.DataFrame([student.__dict__ for student in students])
    query = query.drop(["_sa_instance_state"],axis=1).reindex(["name","major","score","extra_activity","academic_achievement","nonacademic_achievement"],axis=1).rename({"extra_activity": "activity","academic_achievement": "achievement"},axis=1)

    process = Process(query)
    process.process()

    _data = list(process.data["accept_status"].value_counts())
    _label = ["No","Yes"]
    fig =  pie(process.data,names=_label,values=_data,title="persentase perkiraan diterima di smnptn")
    pie_json = dumps(fig,cls=PlotlyJSONEncoder)

    fig = bar(process.data,x=_label,y=_data,color=_label)
    bar_json = dumps(fig,cls=PlotlyJSONEncoder)

    data = process.data.rename({"name": "Nama","major": "Jurusan","score": "Nilai","activity": "Keaktifan ekskul","achievement": "Prestasi akademik","nonacademic_achievement": "Prestasi non-akademik","accept_status": "Diterima di snpmptn"},axis=1)    
    return render_template("student/index.html",table=data.to_html(table_id="table",classes=["table","table-hover"]),pie_json=pie_json,bar_json=bar_json)

@admin.route("/student/evaluate")
def evaluate():
    students = Student.query.all()
    query = pd.DataFrame([student.__dict__ for student in students])
    query = query.drop(["_sa_instance_state"],axis=1).reindex(["name","major","score","extra_activity","academic_achievement","nonacademic_achievement"],axis=1).rename({"extra_activity": "activity","academic_achievement": "achievement"},axis=1)

    process = Process(query)
    process.process()

    confusion_matrix = process.confusion_matrix
    _confusion_matrix = create_annotated_heatmap(z=confusion_matrix.tolist(),x=["0","1"],y=["0","1"],colorscale="purp")
    plotly_json = dumps(_confusion_matrix,cls=PlotlyJSONEncoder)

    print(process.classification_score)

    return render_template("student/evaluate.html",plotly_json=plotly_json,score=process.score,classification_report=process.classification_score)

@admin.route("/student/scores",methods=["GET","POST"])
@is_admin
@login_required
def student_scores():
    forms: StudentGradeForm = StudentGradeForm()

    if request.method == "POST" and forms.validate_on_submit():
        return redirect(url_for("admin.student_scores_subject",subject=forms.subject.data,class_name=forms.class_name.data,semester=forms.semester.data))

    return redirect(url_for("admin.student_scores_subject"))

@admin.route("/student/scores/subject")
@is_admin
@login_required
def student_scores_subject():
    subject = request.args.get("subject","agama")
    class_name = request.args.get("class_name","1")
    semester_name = request.args.get("semester","1")

    forms: StudentGradeForm = StudentGradeForm()
    _student: list[Student] = Student.query.all()
    scores_arr = []

    for student in _student:
        if student.scores:

            try:
                scores = loads(student.scores).get(class_name,{})[f"semester{semester_name}"]["scores"][subject.lower()]
            except KeyError as e:
                scores = {"tugas 1": "-","tugas 2": "-","tugas 3": "-","tugas 4": "-","ulangan 1": "-","ulangan 2": "-"}
                if subject.lower() == "nilai sikap":
                    scores = loads(student.scores).get(class_name,{})[f"semester{semester_name}"]["scores"]
                    scores = {"Disiplin": scores.get("displin","-"),"Percaya diri": scores.get("percayadiri","-")}

                print(e)

            scores["name"] = student.name
            # scores["class"] = student._class
            scores["nik"] = f"<a href={url_for('admin.edit_student',nik=student.nik)} class='text-decoration-none'>{student.nik}</a>"
            scores_arr.append(scores)

    data_scores =  pd.DataFrame(scores_arr)
    if len(data_scores) > 0:
        try:
            data_scores = data_scores.drop(["semester_score","scores"],axis=1)
        except KeyError:
            pass
        data_scores = data_scores.rename(columns=str.capitalize)
        name_column = data_scores.pop("Name")
        # class_column = data_scores.pop("Class")
        nik_column = data_scores.pop("Nik")
        data_scores.insert(0,"NIK",nik_column)
        data_scores.insert(1,"Nama",name_column)
        # data_scores.insert(2,"kelas",class_column)
    return render_template("student/scores.html",tables=data_scores.to_html(classes=["table","table-hover"],escape=False,index=False,table_id="table"),title="Nilai tugas dan ulangan",subject=subject,class_name=class_name,semester_name=semester_name,add_url="admin.student_scores_add",add_button_text="Tambah  nilai murid",submit_url="admin.student_scores" ,forms=forms)

@admin.route("/student/scores/add",methods=["GET","POST"])
def student_scores_add():
    forms: StudentDataFile = StudentDataFile()

    def avg(score):
        return {"tugas 1": score["tugas1"],"tugas 2": score["tugas2"],"tugas 3": score["tugas3"],"tugas 4": score["tugas4"],"Ulangan 1": score["ujian1"],"Ulangan 2": score["ujian2"] }

    if request.method == "POST" and forms.validate_on_submit():
        file = request.files[forms.student_data.name]
        pattern = r"(nilai|scores)_(kelas|class)_[1-6](a|b)_(semester1|semester2).xlsx$"
        check,msg = check_files(file,filename_pattern=pattern,pattern_not_match_msg="Format file salah, file harus diawali dengan scores atau nilai lalu dengan nama kelas kemudian nama semester,contoh: nilai_kelas_1a_semester1.xlsx atau scores_class_1a_semester1.xlsx ")

        if not check:
            flash(msg,category="danger")
            return redirect(url_for("admin.student_scores_add"))

        sheet_names = pd.ExcelFile(file).sheet_names
        data = None

        scores = pd.DataFrame(columns=["nama",*sheet_names])
        try:
            for sheet in sheet_names:
                if sheet != "NILAI SIKAP":
                    data: pd.DataFrame = pd.read_excel(file,sheet)
                    scores[sheet] = data.apply(avg,axis=1)
        except KeyError as e:
            flash(f"File error, file tidak memiliki data {e}",category="danger")
            return redirect(url_for("admin.student_scores_add"))

        scores = scores.rename(columns=str.lower)
        scores["displin"] = pd.read_excel(file,"NILAI SIKAP")["displin"]
        scores["percayadiri"] = pd.read_excel(file,"NILAI SIKAP")["percayadiri"]

        scores["nama"] = data["nama"].str.capitalize()
        scores["nik"] = data["nik"]
        scores = scores.drop(["nilai sikap"],axis=1)
        scores = scores.to_dict(orient="records")

        filename_list = file.filename.split("_")
        class_name = filename_list[2][0]
        semester_name = filename_list[3].split(".")[0]

        try:
            student_with_scores = 0

            for score in scores:
                print(score.keys())
                _student: Student = Student.query.filter_by(nik=score["nik"]).first()

                try:
                    _student.scores = loads(_student.scores) if _student.scores else {}
                    check_score = _student.scores.get(class_name,None)
                    if not check_score:
                        # if not scores of class or semester is none
                        print("add new")
                        _student.scores[class_name] =  {semester_name: {"scores": score,"semester_score": {}}}
                        _student.scores = dumps(_student.scores)
                        print("_student.scores")
                        db.session.commit()
                    elif check_score[semester_name]:
                        # if the semester is none
                        _student.scores[class_name][semester_name]["scores"] = score
                        _student.scores = dumps(_student.scores)
                        print(_student.scores)
                        db.session.commit()
                    else:
                        # if both exist just update the scores
                        # _student.scores[class_name][semester_name] = {"scores": score}
                        # _student.scores = dumps(_student.scores)
                        # db.session.commit()
                        # student_with_scores += 1
                        print("skipped")
                except AttributeError:
                    pass
        except Exception as e:
            traceback.print_exception(*sys.exc_info())
            db.session.rollback()
        else:
            if student_with_scores <= 0:
                flash("Nilai murid berhasil ditambahkan",category="success")
            else:
                flash(f"Nilai murid berhasil ditambahkan, {student_with_scores} murid diupdate karena nilai sudah terisi",category="success")
            return redirect(url_for("admin.student_scores"))

    forms.student_data.label = "Tambah nilai murid, contoh format nama file: nilai_kelas_1a_semester1.xlsx"
    if len(Student.query.all()) <= 0:
        flash("Data murid masih kosong, tolong isi data murid dengan menguplad file excel nya",category="danger")
        return redirect(url_for("admin.student"))

    return render_template("admin/add.html",forms=forms,title="Tambah nilai murid")

@admin.route("/student/presention",methods=["GET","POST"])
@is_admin
@login_required
def student_presention():
    forms: StudentGradeSemesterForm = StudentGradeSemesterForm()

    class_name = request.args.get("class_name","1")
    semester_name = request.args.get("semester","1")

    if request.method == "POST":
        return redirect(url_for("admin.student_presention",class_name=forms.class_name.data,semester_name=forms.semester.data))

    _students: list[Student] = Student.query.all()
    data_presention = pd.DataFrame()
    _student_arr = []

    for _student in _students:
        if _student.presention:
            _presention = loads(_student.presention)[class_name][f"semester{semester_name}"] if loads(_student.presention).get(class_name,None) else {"S": "-","I": "-","A": "-"}
            _presention["Nama"] = _student.name
            # _presention["Kelas"] = _student._class
            _presention["NIK"] = f"<a href={url_for('admin.edit_student',nik=_student.nik)} class='text-decoration-none'>{_student.nik}</a>"
            _student_arr.append(_presention)

    if len(_student_arr):
        data_presention = pd.DataFrame(_student_arr)
        name_column = data_presention.pop("Nama")
        # class_column = data_presention.pop("Kelas")
        nik_column = data_presention.pop("NIK")
        data_presention.insert(0,"NIK",nik_column)
        data_presention.insert(1,"Nama",name_column)
        if data_presention.get("No.",None) or data_presention.get("nik",None):
            data_presention=data_presention.drop(["No.","nik"],axis=1)
        # data_presention.insert(2,"Kelas",class_column)

    return render_template("student/scores.html",tables=data_presention.to_html(classes=["table","table-hover"],escape=False,index=False,table_id="table"),title="Absen murid",add_url="admin.student_presention_add",submit_url="admin.student_presention",class_name=class_name,semester_name=semester_name,add_button_text="Tambah absen murid",forms=forms)

@admin.route("/student/presention/add", methods=["GET","POST"])
@is_admin
@login_required
def student_presention_add():
    forms: StudentDataFile = StudentDataFile()

    if request.method == "POST" and forms.validate_on_submit():
        file = request.files[forms.student_data.name]

        filename_list = file.filename.split("_")
        class_name = filename_list[2][0]
        semester_name = filename_list[3].split(".")[0]

        pattern = r"absensi_(kelas|class)_[1-6](a|b)_(semester1|semester2).xlsx$"
        check,msg = check_files(file,filename_pattern=pattern,pattern_not_match_msg="format nama file salah")

        if not check:
            flash(msg,category="danger")
            return redirect(url_for("admin.student_presention_add"))

        _students_presention = pd.read_excel(file)
        try:
            _students_presention = _students_presention.drop(_students_presention.columns[_students_presention.columns.str.contains('unnamed',case = False)],axis = 1).fillna(0)
        except KeyError as e:
            flash(f"File error, file tidak memiliki data {e}",category="danger")
            return redirect(url_for("admin.student_presention_add"))

        _students_presention["nama"] = _students_presention["nama"].str.capitalize()
        _students_presention["A"] = _students_presention["A"].astype(int)
        _students_presention = _students_presention.rename({"Nama Siswa": "nama"},axis=1)
        _students_presention =  _students_presention.to_dict(orient="records")

        try:
            for presention in _students_presention:
                _student: Student = Student.query.filter_by(nik=presention["nik"]).first()
                _student_presention = loads(_student.presention) if _student.presention else {}
                try:
                    del presention["nama"]

                    if not _student_presention.get(class_name,None):
                        _student_presention = {class_name: {semester_name: presention }}
                        _student.presention = dumps(_student_presention)
                        db.session.commit()
                    elif _student_presention[class_name]:
                        _student_presention[class_name][semester_name] = presention
                        _student.presention = dumps(_student_presention)
                        db.session.commit()
                    else:
                        print("skiping student")
                except AttributeError:
                    pass
        except Exception as e:
            traceback.print_exception(*sys.exc_info())
            db.session.rollback()
        else:
            flash("Absensi murid berhasil ditambahkan",category="success")
            return redirect(url_for("admin.student_presention"))

    forms.student_data.label = "Tambah absen, contoh format nama file: absensi_kelas_5a_semester1.xlsx"
    if len(Student.query.all()) <= 0:
        flash("Data murid masih kosong, tolong isi data murid dengan menguplad file excel nya",category="danger")
        return redirect(url_for("admin.student"))

    return render_template("admin/add.html",forms=forms,title="Tambah absen murid",btn_title="murid")

@admin.route("/student/semester",methods=["GET","POST"])
@is_admin
@login_required
def student_semester():
    forms: StudentGradeSemesterForm = StudentGradeSemesterForm()
    semester_name = request.args.get("semester","1")
    class_name = request.args.get("class_name","1")

    if request.method == "POST":
        return redirect(url_for("admin.student_semester",class_name=forms.class_name.data,semester=forms.semester.data))

    data_semester = pd.DataFrame()
    _students: list[Student] = Student.query.all()
    _student_arr = []

    for _student in _students:
        if _student.scores:

            semester_scores = {}
            try:
                _scores = loads(_student.scores)[class_name][f"semester{semester_name}"]
            except KeyError as e:
                print("error")
                semester_scores = {'pag': "-", 'pkn': "-", 'b. ind': "-", 'mmk': "-", 'ipa': "-", 'ips': "-", 'sbk': "-", 'pjok': "-", 'b. ing': "-"}
            else:
                print(_scores)
                semester_scores = _scores["semester_score"] if _scores.get("semester_score") else {'pag': "-", 'pkn': "-", 'b. ind': "-", 'mmk': "-", 'ipa': "-", 'ips': "-", 'sbk': "-", 'pjok': "-", 'b. ing': "-"}

            semester_scores["Nama"] = _student.name
            # _scores["Kelas"] = _student._class
            semester_scores["NIK"] = f"<a href={url_for('admin.edit_student',nik=_student.nik)} class='text-decoration-none'>{_student.nik}</a>"
            _student_arr.append(semester_scores)

    if len(_student_arr):
        data_semester = pd.DataFrame(_student_arr).rename({"pag": "agama"}).rename(columns=str.capitalize)
        print(data_semester)

        name_column = data_semester.pop("Nama")
        # class_column = data_semester.pop("Kelas")
        nik_column = data_semester.pop("Nik")
        data_semester.insert(0,"NIK",nik_column)
        data_semester.insert(1,"Nama",name_column)
        # data_semester.insert(2,"Kelas",class_column)

    return render_template("student/scores.html",tables=data_semester.to_html(classes=["table","table-hover"],escape=False,index=False,table_id="table"),semester_name=semester_name,class_name=class_name,title="Nilai semester",add_url="admin.student_semester_add",add_button_text="Tambah  nilai semester",forms=forms,submit_url="admin.student_semester")

@admin.route("/student/semester/add",methods=["GET","POST"])
@is_admin
@login_required
def student_semester_add():
    forms: StudentDataFile = StudentDataFile()

    if request.method == "POST" and forms.validate_on_submit():
        file = request.files[forms.student_data.name]
        data_semester = pd.read_excel(file)

        pattern = r"(nilaiSemester|scoresSemester)_(kelas|class)_[1-6](a|b)_(semester1|semester2).xlsx$"
        check,msg = check_files(file,filename_pattern=pattern,pattern_not_match_msg="Format file salah, file harus diawali dengan scores atau nilai lalu dengan nama kelas kemudian nama semester,contoh: semester_kelas_1a_semester1.xlsx atau semester_class_1a_semester1.xlsx ")

        if not check:
            flash(msg,category="danger")
            return redirect(url_for("admin.student_semester_add"))

        data_semester = data_semester.rename(columns=str.lower).rename(columns=str.strip)

        try:
            data_semester["nama"] = data_semester["nama"].str.capitalize()
            data_semester = data_semester.rename(columns=str.strip).rename({"pag": "agama","b. ind": "b.indo","mmk": "mm","b. ing": "b.ing"},axis=1)
            print(data_semester["pjok"])
            data_semester = pd.DataFrame({"nama": data_semester["nama"],"nik": data_semester["nik"],"agama": data_semester["agama"],"b.indo": data_semester["b.indo"],"mm": data_semester["mm"],"b.ing": data_semester["b.ing"],"pkn": data_semester["pkn"],"ipa": data_semester["ipa"],"ips": data_semester["ips"],"sbk": data_semester["sbk"],"pjok": data_semester["pjok"]})
            data_semester = data_semester.to_dict(orient="records")
        except KeyError as e:
            traceback.print_exception(*sys.exc_info())
            flash(f"File error, file tidak memiliki data {e}",category="danger")
            return redirect(url_for("admin.student_semester_add"))



        filename_list = file.filename.split("_")
        class_name = filename_list[2][0]
        semester_name = filename_list[3].split(".")[0]

        student_without_scores = []

        try:
            for score in data_semester:
                print(score.keys())
                _student: Student = Student.query.filter_by(nik=score["nik"]).first()
                if _student.scores:
                    try:
                        _semester_score = loads(_student.scores)
                        del score["nama"]
                        del score["nik"]
                        _semester_score[class_name][semester_name]["semester_score"] = score
                        _student.scores = dumps(_semester_score)
                        db.session.commit()
                    except AttributeError as e:
                        print(e)
                    except KeyError:
                        student_without_scores.append(_student.name)
                else:
                    student_without_scores.append(_student.name)
        except Exception as e:
            print(str(e))
            db.session.rollback()
        else:
            flash("Nilai semester murid berhasil ditambahkan",category="success")

            flash(f"Murid dengan nama {','.join(student_without_scores)} masih memiliki nilai ulangan dan tugas {semester_name}  yang masih kosong",category="danger")

            return redirect(url_for("admin.student_semester"))

    forms.student_data.label = "Tambah nilai semester, contoh format nama file: nilaiSemester_kelas_1a_semester1.xlsx"

    return render_template("admin/add.html",forms=forms,title="Tambah nilai semester",btn_title="murid")

@admin.route("/student/delete/<int:id>")
@is_admin
@login_required
def delete_student(id):
    _student = Student.query.filter_by(id=id).first()

    db.session.delete(_student)
    db.session.commit()

    flash(message=f"data murid {_student} telah dihapus ",category="danger")
    return redirect(url_for("admin.student"))

@admin.route("/users")
@is_admin
@login_required
def user_page():
    users = User.query.filter(id != current_user.id ).all()
    users = to_tables(users,drop_column=["_sa_instance_state"],reorder_column=["username","email","role"])

    return render_template("admin/tables.html",tables=users,add_url="admin.user_add",add_button_text="Tambah user baru",title="User")

@admin.route("/users/add",methods=["GET","POST"])
@login_required
@is_admin
def user_add():
    forms: AddUserForm = AddUserForm()

    if request.method == "POST" and forms.validate_on_submit():
        user = User(forms.username.data,forms.email.data,forms.password1.data,"teacher")
        try:
            user.add()
        except:
            flash(f"User dengan emait atau username yang sama sudah ada",category="danger")
            return redirect(url_for("admin.user_add"))
        return redirect(url_for("admin.user_page"))

    return render_template("admin/add.html",forms=forms,title="Tambah user",btn_title="user")

@admin.route("/users/edit/<int:id>",methods=["GET","POST"])
@login_required
@is_admin
def user_edit(id):
    forms: AddUserForm = AddUserForm()
    _user: User = User.query.filter_by(id=id).first()

    forms.username.data = _user.username
    forms.email.data = _user.email
    forms.password1.data = ""
    forms.password2.data = ""

    return render_template("admin/add.html",forms=forms,title="Edit user",edit=True,btn_title="user")
